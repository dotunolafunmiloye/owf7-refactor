/**
 * In Grails 1.0.x this is called after the staging dir is prepared but before the war is packaged.
 */
eventWarStart = { name ->
	if (name instanceof String || name instanceof GString) {
		versionResources name, stagingDir
	}
}

/**
 * In Grails 1.1+ this is called after the staging dir is prepared but before the war is packaged.
 */
eventCreateWarStart = { name, stagingDir ->
	def ant = new AntBuilder()
	def baseWebDir = "${basedir}/web-app"

	// copy external themes into the war folder so that uiperformance will run on them
	println "| UiPerformance Plugin: Copying themes to staging area"
	ant.copy(todir:"${stagingDir}/themes", includeemptydirs: false) {
		fileset(dir: "${baseWebDir}/themes") {
			include(name: "**/css/**/*")
			include(name: "**/images/**/*")
			include(name: "**/theme.json")
			exclude(name: "template/**")
			exclude(name: "**/.gitignore")
		}
	}
	ant.delete(includeemptydirs: true, failonerror: false) {
		fileset(dir: "${stagingDir}/themes/common/lib")
		fileset(dir: "${stagingDir}/themes/common/stylesheets")
	}

	println "| UiPerformance Plugin: Copying JS Plugins to staging area..."
	ant.copy(todir:"${stagingDir}/js-plugins", includeemptydirs: false) {
		fileset(dir: "${basedir}/js-plugins") {
			include(name: "**/*.js")
		}
	}

	versionResources name, stagingDir

	// keep old owf bundle name for compatibility
	println "| UiPerformance Plugin: Copying minified JS to js-min..."
	ant.copy(todir: "${stagingDir}/js-min", includeemptydirs: false) {
		fileset(dir: "${stagingDir}/js") {
			include(name: "owf-widget__v*.js")
			exclude(name: "owf-widget__v*gz.js")
		}
		regexpmapper(from: '^(.*)$', to: "owf-widget-min.js")
	}
	ant.copy(file: "${stagingDir}/js/owf-widget.js", tofile: "${stagingDir}/js-min/owf-widget-debug.js")

	// copy back into our webapp for grails run mode
	println "| UiPerformance Plugin: Copying minified JS back to web-app..."
	ant.copy(todir: "${baseWebDir}/js-min", includeemptydirs: false) {
		fileset(dir: "${stagingDir}/js") {
			include(name: "owf-widget__v*.js")
			exclude(name: "owf-widget__v*gz.js")
		}
		regexpmapper(from: '^(.*)$', to: "owf-widget-min.js")
	}
	ant.copy(file: "${stagingDir}/js/owf-widget.js", tofile: "${baseWebDir}/js-min/owf-widget-debug.js")

	ant.delete(includeemptydirs: true, failonerror: false) {
		fileset(dir: "${stagingDir}") {
			include(name: "WEB-INF/templates/**")
			include(name: "WEB-INF/tools")
		}
	}
}

void versionResources(name, stagingDir) {
	def classLoader = Thread.currentThread().contextClassLoader
	classLoader.addURL(new File(classesDirPath).toURL())

	String className = 'com.studentsonly.grails.plugins.uiperformance.ResourceVersionHelper'
	def helper = Class.forName(className, true, classLoader).newInstance()
	println "| UiPerformance Plugin: Versioning resources..."
	helper.version stagingDir, basedir
}
