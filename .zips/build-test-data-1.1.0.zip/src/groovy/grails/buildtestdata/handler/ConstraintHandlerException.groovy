package grails.buildtestdata.handler

public class ConstraintHandlerException extends Exception {
    def ConstraintHandlerException(s) {
        super(s);
    }
}